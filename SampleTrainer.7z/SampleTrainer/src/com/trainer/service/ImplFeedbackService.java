package com.trainer.service;

import java.util.HashMap;

import com.trainer.beans.Trainer;
import com.trainer.dao.FeedbackDAO;
import com.trainer.dao.ImplFeedbackDAO;
import com.trainer.exception.TrainerNotAddedException;

public class ImplFeedbackService implements FeedbackService {
	FeedbackDAO feedbackdao = new ImplFeedbackDAO();

	public ImplFeedbackService(FeedbackDAO feedbackdao) {
		// TODO Auto-generated constructor stub
	}

	// get trainer details from user and send to DAO class
	@Override
	public void addFeedback(Trainer trainer) {
		try {
			feedbackdao.addFeedback(trainer);
		} catch (TrainerNotAddedException e) {
			// TODO Auto-generated catch block
			System.out.println("trainer not added");
		}

	}

	// get trainer list from DAO class and send to main class
	@Override
	public HashMap<Integer, Trainer> getTrainerList() {
		HashMap<Integer, Trainer> trainer = feedbackdao.getTrainerList();
		return trainer;
	}

}
