package com.trainer.testing;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;

import com.trainer.beans.Trainer;
import com.trainer.exception.InvalidDateException;
import com.trainer.exception.TrainerNotAddedException;

class TestCases {

	@Test
	void whenWrongDateIsEntered()throws InvalidDateException{
		Trainer addtrainer=new Trainer("vaibhav123", "java", LocalDate.of(2, 04, 12), LocalDate.of(2, 05, 13), 4);
	}
	
	@Test
	void whenDataIsNotEntered()throws TrainerNotAddedException{
		Trainer addtrainer=new Trainer("vaibhav123", "java", LocalDate.of(2, 04, 12), LocalDate.of(2, 05, 13), 4);
	}

}
