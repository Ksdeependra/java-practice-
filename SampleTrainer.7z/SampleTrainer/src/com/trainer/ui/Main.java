package com.trainer.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.util.Locale;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.trainer.beans.Trainer;
import com.trainer.dao.FeedbackDAO;
import com.trainer.dao.ImplFeedbackDAO;
import com.trainer.exception.InvalidDateException;
import com.trainer.service.FeedbackService;
import com.trainer.service.ImplFeedbackService;

public class Main {
	static Scanner sc = new Scanner(System.in);
	static FeedbackDAO feedbackdao = new ImplFeedbackDAO();
	static FeedbackService service = new ImplFeedbackService(feedbackdao);
	static Trainer trainer = new Trainer(null, null, null, null, 0);

	public static void main(String[] args) {
		while (true) {
			System.out.println("============TRAINER FEEDBACK============");
			System.out.println("1. Add Trainer");
			System.out.println("2. Get Details");
			System.out.println("========================================");
			System.out.println("ENTER YOUR CHOICE :-- ");
			int choice = sc.nextInt();
			System.out.println("========================================");
			switch (choice) {
			case 1:
				AddTrainer();
				break;
			case 2:
				GetDetails();
				break;
			default:
				System.out.println("****WRONG CHOICE****");
			}
		}

	}

	// get trainer details from feedback service class
	private static void GetDetails() {
		System.out.println("");
		System.out.println("****TRAINER DETAILS****");
		System.out.println("");
		System.out.println(service.getTrainerList());
		System.out.println("");

	}

	// add trainer details
	private static void AddTrainer() {
		System.out.println("");
		System.out.println("Enter Trainer Name : ");
		String trainername = sc.next();
		System.out.println("Enter Course Name : ");
		String coursename = sc.next();
		System.out.println("Enter Start Date, Month, Year : ");
		int startdate = sc.nextInt();
		int startmonth = sc.nextInt();
		int startyear = sc.nextInt();
		System.out.println("Enter End Date, Month, Year : ");
		int enddate = sc.nextInt();
		int endmonth = sc.nextInt();
		int endyear = sc.nextInt();
		System.out.println("Enter Trainer Rating : ");
		int rate = sc.nextInt();
		if (validatetrainername(trainername) && validatecoursename(coursename) && validaterating(rate)) {
			trainer.setCourseName(coursename);
			trainer.setEndDate(LocalDate.of(endyear, endmonth, enddate));
			trainer.setRating(rate);
			trainer.setStartDate(LocalDate.of(startyear, startmonth, startdate));
			trainer.setName(trainername);
			service.addFeedback(trainer);
			System.out.println("");
			System.out.println("****TRAINER ADDED SUCCESSFULLY****");
			System.out.println("");
		}

	}

	// validate rating
	private static boolean validaterating(int rate) {
		if (rate < 0 && rate > 5)
			System.out.println("Enter Valid Rating Between 0 to 5");
		return true;
	}

	// validate course name
	private static boolean validatecoursename(String coursename) {
		Pattern pattern = Pattern.compile("[A-Za-z]{1,20}");
		Matcher match = pattern.matcher(coursename);
		if (!(match.matches()))
			System.out.println("Enter valid Course Name");
		return true;
	}

	// validate trainer name
	private static boolean validatetrainername(String trainername) {
		Pattern pattern = Pattern.compile("[A-Za-z]{1,20}");
		Matcher match = pattern.matcher(trainername);
		if (!(match.matches()))
			System.out.println("Enter Valid Trainer Name");
		return true;
	}

	private static boolean validateDate(int day, int month, int year) throws InvalidDateException {
		DateTimeFormatter dt = DateTimeFormatter.ofPattern("dd-MM-uuuu", Locale.US)
				.withResolverStyle(ResolverStyle.STRICT);
		LocalDate.parse("" + day + "-" + month + "-" + year, dt);
		return true;
	}

}
