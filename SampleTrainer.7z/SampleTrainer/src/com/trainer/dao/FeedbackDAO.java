package com.trainer.dao;

import java.util.HashMap;

import com.trainer.beans.Trainer;
import com.trainer.exception.TrainerNotAddedException;

public interface FeedbackDAO {
	public void addFeedback(Trainer trainer) throws TrainerNotAddedException;

	public HashMap<Integer, Trainer> getTrainerList();

}
