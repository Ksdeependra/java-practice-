package com.trainer.dao;

import java.util.HashMap;

import com.trainer.beans.Trainer;
import com.trainer.exception.TrainerNotAddedException;
import com.trainer.util.DBUtil;
 
public class ImplFeedbackDAO implements FeedbackDAO {
	
	//add trainer details in hash map
	@Override
	public void addFeedback(Trainer trainer) throws TrainerNotAddedException {
		HashMap<Integer, Trainer> newtrainer=DBUtil.getFeedbackList();
		newtrainer.put((int)(Math.random()*1000), trainer);
	}

	//get trainer details from DBUtil and send to service class
	@Override
	public HashMap<Integer, Trainer> getTrainerList() {
		HashMap<Integer, Trainer> trainer=DBUtil.getFeedbackList();
		return trainer;
	}

	
}
