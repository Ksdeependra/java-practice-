package com.trainer.exception;

public class TrainerNotAddedException extends Exception {

}
