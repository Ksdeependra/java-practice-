package com.trainer.exception;

public class InvalidDateException extends Exception {

}
