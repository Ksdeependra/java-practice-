package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.InvalidMobileNumberException;

public class AccountServiceImpl implements AccountService{
    AccountDao accountDao=new AccountDaoImpl();

	@Override
	public Account getAccountDetails(String mobileNo) throws InvalidMobileNumberException {
		return accountDao.getAccountDetails(mobileNo);
		
	}

	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) throws InvalidMobileNumberException {
		return accountDao.rechargeAccount( mobileNo,rechargeAmount);
		
	}
    
	
//service implementation//
}
