package com.cg.mra.exception;

public class InvalidMobileNumberException extends Exception{

}
//exception handling//