package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.InvalidMobileNumberException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI {

	public static void main(String[] args) throws Exception{
		AccountService accountService=new AccountServiceImpl();
		Scanner sc=new Scanner(System.in);
		while(true) 
		{
			System.out.println("Choose options");
			System.out.println("1.Account Balance Enquiry");
			System.out.println("2.Recharge Account");
			System.out.println("3.Exit");
			int choice=sc.nextInt();
			sc.nextLine();
			switch(choice)
			{
			case 1:
				System.out.println("Enter mobileNo");
				String mobileNo=sc.nextLine();
				boolean check=true;
				while(check)
				{
					if(mobileNo.length()==10)
					{
						check=false;
						
					}else
					{
						System.out.println("Enter valid mobileNo");
						mobileNo=sc.nextLine();
					}
				}
				try {
					Account account=accountService.getAccountDetails(mobileNo);
					System.out.println("Your account balance is"+ accountService.getAccountDetails(mobileNo));
				}catch(InvalidMobileNumberException e) {
					System.out.println("Wrong Mobile Number");
				}
				
				break;
			case 2:
				System.out.println("Enter mobile number");
				String mobileNo1=sc.nextLine();
				System.out.println("Enter recharge amount");
				Double rechargeAmount=sc.nextDouble();
				System.out.println(accountService.rechargeAccount(mobileNo1, rechargeAmount));
				
				break;
			case 3:
				System.exit(0);
				
				
			}
			
		}
		
		
		
		//main method//
			

 }
}
