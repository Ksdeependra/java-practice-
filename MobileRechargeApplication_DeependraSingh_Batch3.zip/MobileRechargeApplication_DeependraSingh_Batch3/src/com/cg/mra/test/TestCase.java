package com.cg.mra.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.mra.exception.InvalidMobileNumberException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class TestCase {

	AccountService accountService=new AccountServiceImpl();

	@Test
	public void test() throws InvalidMobileNumberException {
		accountService.getAccountDetails("9010210131");
	}

}
//test cases//