package com.capgemini.exception;

public class DuplicateProductIdException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


}
