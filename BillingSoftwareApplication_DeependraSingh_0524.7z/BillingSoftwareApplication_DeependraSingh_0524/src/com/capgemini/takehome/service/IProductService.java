package com.capgemini.takehome.service;

import java.io.InvalidClassException;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.exception.InvalidProductCodeException;
import com.capgemini.takehome.exception.InvalidProductCodeException;

public interface IProductService {
	Product getProductDetails(int productCode) throws InvalidProductCodeException;
	

}
