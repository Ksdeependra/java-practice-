package com.capgemini.takehome.service;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.dao.IProductDAO;
import com.capgemini.takehome.dao.ProductDAO;
import com.capgemini.takehome.exception.InvalidProductCodeException;
import com.capgemini.takehome.exception.InvalidProductCodeException;

public class ProductService implements IProductService{
	IProductDAO iproductdao;
	  public ProductService(IProductDAO iproductdao ) {
    	  this.iproductdao=iproductdao;
      }

	@Override
	public Product getProductDetails(int productCode) throws InvalidProductCodeException {

		  return iproductdao.getProductDetails(productCode);
		
		
	}
	
}	
      

