package com.capgemini.takehome.exception;

public class InvalidProductCodeException extends Exception {
	
}
