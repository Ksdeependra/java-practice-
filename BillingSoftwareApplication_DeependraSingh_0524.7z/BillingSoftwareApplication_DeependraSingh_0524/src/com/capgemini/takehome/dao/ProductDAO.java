package com.capgemini.takehome.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.exception.InvalidProductCodeException;
import com.capgemini.takehome.util.CollectionUtil;

public class ProductDAO implements IProductDAO {
		Product product;
		CollectionUtil  collectionUtil;
		Map<Integer, Product> hmap=new HashMap<Integer, Product>();

		@Override
		public Product getProductDetails(int productCode) throws InvalidProductCodeException {
			product=collectionUtil.getProducts().get(productCode);
			if(product==null)
				throw new InvalidProductCodeException();
			return product;
		}
		
	
	
		
}
//Dao implementation//
