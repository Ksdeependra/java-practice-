package com.cg.exception;

public class InvalidRatingException extends Exception{

}
