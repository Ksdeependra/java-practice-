package com.cg.exception;

public class InvalidCourseNameException extends Exception {

}
