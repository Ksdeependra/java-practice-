package com.cg.exception;

public class InvalidNameException extends Exception {
	

}
