package com.cg.mra.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.MobileRechargeException;

public class AccountServiceImpl implements AccountService {
	AccountDao accountdao = new AccountDaoImpl();
	
   
	@Override
	public Account getAccountDetails(String mobileNo) {
		return accountdao.getAccountDetails(mobileNo);
	
		
	}

	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) {
		return accountdao.rechargeAccount(mobileNo,rechargeAmount);
	
	}

	@Override
	public boolean validateMobileNo(String mobileNo) throws MobileRechargeException {
		if(mobileNo==null) 
			throw new  MobileRechargeException("Mobile No. is not to be null");
		  Pattern pat=Pattern.compile("[6-9]{1}[0-9]{9}");
		  Matcher mat=pat.matcher(mobileNo);
		  return mat.matches();
		  
	}

	@Override
	public boolean validateRechargeAmount(double rechargeAmount) throws MobileRechargeException {
		if(rechargeAmount<0)
		{
			return false;
		}
		else if(rechargeAmount==0);
		{
		throw new MobileRechargeException("Recharge cannot be zero");
		}
	}

}
