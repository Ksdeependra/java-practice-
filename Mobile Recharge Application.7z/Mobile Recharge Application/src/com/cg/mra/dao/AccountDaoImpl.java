package com.cg.mra.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.mra.beans.Account;

public class AccountDaoImpl implements AccountDao {
	Map<String,Account>accountEntry;
	public AccountDaoImpl() {
		accountEntry=new HashMap<>();
		accountEntry.put("9512354563",new Account("Prepaid","Vaishali",200));
		accountEntry.put("9513454563",new Account("Prepaid","Megha",453));
		accountEntry.put("9513686563",new Account("Prepaid","Vikas",631));
		accountEntry.put("9532135563",new Account("Prepaid","Anju",521));
		accountEntry.put("9564354563",new Account("Prepaid","Tushar",632));
	}

	@Override
	public Account getAccountDetails(String mobileNo) {
		if(accountEntry.containsKey(mobileNo))
		{
			return accountEntry.get(mobileNo);
		}
		return null;
	}

	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) {
		double balance=0;
		if(accountEntry.containsKey(mobileNo))
		{
			Account a1=accountEntry.get(mobileNo);
			balance=rechargeAmount+a1.getAccountBalance();
			a1.setAccountBalance(balance);
		}
		return balance;
	}
	
	
	

}
