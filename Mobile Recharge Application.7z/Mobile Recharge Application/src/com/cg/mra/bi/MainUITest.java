package com.cg.mra.bi;

import static org.junit.Assert.*;



import javax.security.auth.login.AccountException;
import org.junit.Test;

import com.cg.mra.exception.MobileRechargeException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUITest {
	
	public MainUITest() {
			// TODO Auto-generated constructor stub
	}

	@Test(expected=AccountException.class)
	public void ValidateMobileNumber_v1() throws MobileRechargeException {
		AccountService accservice=new AccountServiceImpl();
		accservice.validateMobileNo(null);
		
	}
	@Test
	public void ValidateMobileNumber_v5() throws MobileRechargeException  {
		AccountService accservice=new AccountServiceImpl();
		boolean result=accservice.validateMobileNo("78965412023"); // greater than 10 digits
		assertEquals(false, result);
		
	}
	
	@Test
	public void ValidateRechargeAmount_v1() throws MobileRechargeException  {
		AccountService accservice=new AccountServiceImpl();
		boolean result=accservice.validateRechargeAmount(-25); // negative recharge amount
		assertEquals(false, result);
		
	}
	
	@Test
	public void ValidateRechargeAmount_v2() throws MobileRechargeException  {
		AccountService accservice=new AccountServiceImpl();
		boolean result=accservice.validateRechargeAmount(100); // correct recharge amount format
		assertEquals(true, result);
		
	}
	
	@Test(expected=AccountException.class)
	public void ValidateRechargeAmount_v3() throws MobileRechargeException {
		AccountService accservice=new AccountServiceImpl();
		accservice.validateRechargeAmount(0);
		
	}
	
	

}
