package com.cg.mra.bi;

import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI {

	public static void main(String[] args) throws Exception {
		AccountService s1=new AccountServiceImpl();
		Scanner sc=new Scanner(System.in);
		while(true)
		{
			System.out.println("1. Account Balance Enquiry");
			System.out.println("2. Recharge Amount");
			System.out.println("3. Exit");
			int choice=sc.nextInt();
			switch(choice)
			{

			case 1:
				System.out.println("Enter Mobile No : ");
				String mobileNo=sc.next();
				if(s1.validateMobileNo(mobileNo)){
					Account acc=s1.getAccountDetails(mobileNo);
					if(acc==null)
						System.out.println("Given Account Id Does Not Exits ");
					else
						System.out.println("Your Current Balance is Rs. "+acc.getAccountBalance());
				}
				
				else
					System.out.println("Enter 10 digit Mobile Number");
				
				break;
				
			case 2:
				System.out.println("Enter MobileNo : ");
				String mobNo=sc.next();
				System.out.println("Enter Recharge Amount : ");
				double amount=sc.nextDouble();
				if(s1.validateMobileNo(mobNo))				 												//if no.1 for validating mobile number =
				{
					if(amount==0){																				//if no.2 for ensuring recharge amount cannot be zero
						System.out.println("Recharge amount cannot be zero");
					}																							//end of if no.2
					else if(s1.validateRechargeAmount(amount))													//else if for validating recharge amount
					{
						double newbalance=s1.rechargeAccount(mobNo, amount);
						if(newbalance==0){																		//if no.3 method returns 0 if no mobile number is existing 
						System.out.println("Cannot Recharge Account as Given Mobile No Does Not Exists ");
						}																						//end of if no.3
						else{	
						Account acc1=s1.getAccountDetails(mobNo);
						System.out.println("Your Account Recharged Successfully");
						System.out.println("Hello "+acc1.getCustomerName()+",Available Balance is "+newbalance+".");
						}
					}																							//end of else if
					else
						System.out.println("enter valid Recharge Amount");
					
				
					
				}																								// end of if no.1
				else
					System.out.println("Enter 10 digit Mobile Number");
				
				
				break;
			
			
				
			
			}
			
		}
		
		
		

	}

}
